from __future__ import annotations

import base64
import json
import os
from dataclasses import dataclass
from typing import Any

from argon2.low_level import Type, hash_secret_raw
from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM


class VaultCryptoError(Exception):
    """Base error for vault cryptography."""


class InvalidMasterPassword(VaultCryptoError):
    """Raised when a vault cannot be authenticated with the supplied password."""


@dataclass(frozen=True, slots=True)
class KdfParameters:
    time_cost: int = 4
    memory_cost_kib: int = 96 * 1024
    parallelism: int = 2
    hash_len: int = 32

    def to_dict(self) -> dict[str, int | str]:
        return {
            "algorithm": "argon2id",
            "time_cost": self.time_cost,
            "memory_cost_kib": self.memory_cost_kib,
            "parallelism": self.parallelism,
            "hash_len": self.hash_len,
        }

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "KdfParameters":
        if value.get("algorithm") != "argon2id":
            raise VaultCryptoError("Unsupported vault key-derivation algorithm")
        return cls(
            time_cost=int(value["time_cost"]),
            memory_cost_kib=int(value["memory_cost_kib"]),
            parallelism=int(value["parallelism"]),
            hash_len=int(value.get("hash_len", 32)),
        )


DEFAULT_KDF = KdfParameters()
AAD = b"RMD-VAULT-V1"


def _b64e(value: bytes) -> str:
    return base64.b64encode(value).decode("ascii")


def _b64d(value: str) -> bytes:
    try:
        return base64.b64decode(value.encode("ascii"), validate=True)
    except Exception as exc:  # noqa: BLE001 - normalize malformed envelope errors
        raise VaultCryptoError("Malformed encrypted vault") from exc


def derive_key(passphrase: str, salt: bytes, params: KdfParameters = DEFAULT_KDF) -> bytes:
    if not isinstance(passphrase, str) or len(passphrase) < 12:
        raise VaultCryptoError("The master passphrase must contain at least 12 characters")
    if len(salt) < 16:
        raise VaultCryptoError("Invalid vault salt")
    return hash_secret_raw(
        secret=passphrase.encode("utf-8"),
        salt=salt,
        time_cost=params.time_cost,
        memory_cost=params.memory_cost_kib,
        parallelism=params.parallelism,
        hash_len=params.hash_len,
        type=Type.ID,
    )


def encrypt_payload(payload: dict[str, Any], key: bytes, salt: bytes, params: KdfParameters) -> dict[str, Any]:
    if len(key) != 32:
        raise VaultCryptoError("Invalid vault key")
    nonce = os.urandom(12)
    plaintext = json.dumps(payload, ensure_ascii=False, separators=(",", ":"), sort_keys=True).encode("utf-8")
    ciphertext = AESGCM(key).encrypt(nonce, plaintext, AAD)
    return {
        "format": "rmd-vault",
        "version": 1,
        "kdf": params.to_dict(),
        "salt": _b64e(salt),
        "nonce": _b64e(nonce),
        "ciphertext": _b64e(ciphertext),
    }


def create_envelope(payload: dict[str, Any], passphrase: str) -> tuple[dict[str, Any], bytes, bytes, KdfParameters]:
    salt = os.urandom(16)
    params = DEFAULT_KDF
    key = derive_key(passphrase, salt, params)
    return encrypt_payload(payload, key, salt, params), key, salt, params


def decrypt_envelope(envelope: dict[str, Any], passphrase: str) -> tuple[dict[str, Any], bytes, bytes, KdfParameters]:
    try:
        if envelope.get("format") != "rmd-vault" or int(envelope.get("version", -1)) != 1:
            raise VaultCryptoError("Unsupported vault format")
        params = KdfParameters.from_dict(dict(envelope["kdf"]))
        salt = _b64d(str(envelope["salt"]))
        nonce = _b64d(str(envelope["nonce"]))
        ciphertext = _b64d(str(envelope["ciphertext"]))
        if len(nonce) != 12:
            raise VaultCryptoError("Malformed encrypted vault")
        key = derive_key(passphrase, salt, params)
        plaintext = AESGCM(key).decrypt(nonce, ciphertext, AAD)
        payload = json.loads(plaintext.decode("utf-8"))
        if not isinstance(payload, dict):
            raise VaultCryptoError("Malformed vault payload")
        return payload, key, salt, params
    except InvalidTag as exc:
        raise InvalidMasterPassword("Incorrect master passphrase or damaged vault") from exc
    except (KeyError, TypeError, ValueError, json.JSONDecodeError) as exc:
        raise VaultCryptoError("Malformed encrypted vault") from exc
