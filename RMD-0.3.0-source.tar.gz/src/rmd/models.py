from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from typing import Any, Literal
from uuid import uuid4


def utc_now() -> str:
    return datetime.now(UTC).isoformat()


@dataclass(slots=True)
class VaultItem:
    name: str
    username: str
    password: str
    urls: list[str] = field(default_factory=list)
    notes: str = ""
    mfa_enabled: bool = False
    password_changed_at: str = field(default_factory=utc_now)
    compromised_count: int = 0
    tags: list[str] = field(default_factory=list)
    id: str = field(default_factory=lambda: str(uuid4()))
    created_at: str = field(default_factory=utc_now)
    updated_at: str = field(default_factory=utc_now)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "VaultItem":
        created = str(value.get("created_at") or utc_now())
        return cls(
            id=str(value.get("id") or uuid4()),
            name=str(value.get("name", "")),
            username=str(value.get("username", "")),
            password=str(value.get("password", "")),
            urls=[str(url) for url in value.get("urls", [])],
            notes=str(value.get("notes", "")),
            mfa_enabled=bool(value.get("mfa_enabled", False)),
            password_changed_at=str(value.get("password_changed_at") or value.get("updated_at") or created),
            compromised_count=max(0, int(value.get("compromised_count", 0) or 0)),
            tags=[str(tag).strip() for tag in value.get("tags", []) if str(tag).strip()],
            created_at=created,
            updated_at=str(value.get("updated_at") or created),
        )


RiskLevel = Literal[0, 1, 2, 3]


@dataclass(slots=True)
class SecurityFinding:
    code: str
    title: str
    details: str
    severity: Literal["info", "low", "medium", "high", "critical"]
    status: Literal["ok", "warning", "error", "unknown"]
    observed_at: str = field(default_factory=utc_now)
    remediation: str = ""
    category: str = "device"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "SecurityFinding":
        return cls(
            code=str(value.get("code", "unknown")),
            title=str(value.get("title", "Security finding")),
            details=str(value.get("details", "")),
            severity=str(value.get("severity", "medium")),  # type: ignore[arg-type]
            status=str(value.get("status", "unknown")),  # type: ignore[arg-type]
            observed_at=str(value.get("observed_at") or utc_now()),
            remediation=str(value.get("remediation", "")),
            category=str(value.get("category", "device")),
        )


@dataclass(slots=True)
class Incident:
    title: str
    details: str
    severity: Literal["low", "medium", "high", "critical"]
    source_code: str
    status: Literal["open", "acknowledged", "resolved"] = "open"
    id: str = field(default_factory=lambda: str(uuid4()))
    first_seen_at: str = field(default_factory=utc_now)
    last_seen_at: str = field(default_factory=utc_now)
    resolved_at: str = ""
    occurrence_count: int = 1

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "Incident":
        return cls(
            id=str(value.get("id") or uuid4()),
            title=str(value.get("title", "Security incident")),
            details=str(value.get("details", "")),
            severity=str(value.get("severity", "medium")),  # type: ignore[arg-type]
            source_code=str(value.get("source_code", "unknown")),
            status=str(value.get("status", "open")),  # type: ignore[arg-type]
            first_seen_at=str(value.get("first_seen_at") or utc_now()),
            last_seen_at=str(value.get("last_seen_at") or utc_now()),
            resolved_at=str(value.get("resolved_at", "")),
            occurrence_count=max(1, int(value.get("occurrence_count", 1) or 1)),
        )


@dataclass(slots=True)
class ActionRequest:
    action: str
    reason: str
    risk_level: RiskLevel
    target: str = "local-device"
    id: str = field(default_factory=lambda: str(uuid4()))
    requested_at: str = field(default_factory=utc_now)
    approved: bool = False

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
